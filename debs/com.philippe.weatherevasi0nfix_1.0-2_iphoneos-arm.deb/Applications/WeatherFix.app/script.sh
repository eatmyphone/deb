#!/bin/sh

dir=$(dirname "$0")
exec "${dir}/rootexec"