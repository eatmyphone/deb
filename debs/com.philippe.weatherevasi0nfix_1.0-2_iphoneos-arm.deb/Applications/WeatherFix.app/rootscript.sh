#!/bin/bash
chmod -x /usr/libexec/mobile_installation_proxy || true
killall -9 mobile_installation_proxy || true
rm /var/mobile/Library/Caches/com.apple.mobile.installation.plist /var/mobile/Library/Caches/com.apple.LaunchServices-045.csstore || true
launchctl stop com.apple.mobile.installd
launchctl start com.apple.mobile.installd

while [ ! -f /var/mobile/Library/Caches/com.apple.mobile.installation.plist ];
do
      sleep 1
done
while [ ! -f /var/mobile/Library/Caches/com.apple.LaunchServices-045.csstore ];
do
      sleep 1
done

sleep 10

chmod +x /usr/libexec/mobile_installation_proxy || true
sync
reboot