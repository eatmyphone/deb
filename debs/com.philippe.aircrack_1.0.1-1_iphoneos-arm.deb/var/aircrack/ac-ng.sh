#!/bin/sh

cd /
cd var/aircrack
./aircrack-ng -a 1 ./touch.ivs
