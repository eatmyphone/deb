#define _MAJ 0
#define _MIN 9
#define _SUB_MIN 1
#define WEBSITE "http://www.aircrack-ng.org"
