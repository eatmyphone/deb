#!/bin/sh

rm -rf /User/Library/Caches/com.apple.IconsCache/
killall SpringBoard