window.addEventListener("load", function(){
  var a = document.getElementById('son');
  var img = document.getElementById('image');
  img.ontouchend = function(){
    a.play();
  }
}, false);