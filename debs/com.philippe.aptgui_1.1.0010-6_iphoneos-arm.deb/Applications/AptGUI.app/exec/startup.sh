#!/bin/bash

export PATH=$PATH:/usr/sbin:/usr/bin:/sbin:/bin

/Applications/AptGUI.app/exec/firmware.sh

debs=(/var/root/Library/AptGUI/AutoInstall/*.deb)
if [[ ${#debs[@]} -ne 0 && -f ${debs[0]} ]]; then
    dpkg -i "${debs[@]}" 2>/tmp/dpkg.log 1>&2
    rm -f "${debs[@]}"
    cache=

    #killall -9 Lowtide AppleTV
fi

if [[ ${cache+@} ]]; then
    su -c uicache mobile
fi
