#!/bin/sh

if [[ -e /System/Library/Frameworks/PassKit.framework ]]; then
  killall backboardd
else
  killall SpringBoard
fi