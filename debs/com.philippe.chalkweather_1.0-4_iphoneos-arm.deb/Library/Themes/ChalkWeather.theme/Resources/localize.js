var localized = {
	"fr": {
		"strings": {
			"NOW_AT": "Maintenant à ",
			"THIS_WEEK": "Cette semaine :",
			"DAY": "Jour",
			"LOW": "Min",
			"HIGH": "Max",
			"TEMP": "Temps"
		},
		"weekdays": {
			"Sun": "Dim",
			"Mon": "Lun",
			"Tue": "Mar",
			"Wed": "Mer",
			"Thu": "Jeu",
			"Fri": "Ven",
			"Sat": "Sam"
		},
		"weather": [
			"Tornade",				//0
			"Tempête Tropicale",	//1
			"Ouragan",				//2
			"De fortes tempêtes",	//3
			"Pluie + Tonnerre",		//4
			"Pluie + Neige",		//5
			"Neige fondue",			//6
			"Neige fondue",			//7
			"Bruine verglaçante",	//8
			"Bruine",				//9
			"Pluie glaciale",		//10
			"Pluie",				//11
			"Pluie",				//12
			"Fafales de neige",		//13
			"Neige faible",			//14
			"Tempête de neige",		//15
			"Neige",				//16
			"Averse de neige",		//17
			"Neige fondue",			//18
			"Irrégulier",			//19
			"Brouillard",			//20
			"Brume",				//21
			"Enfumé",				//22
			"Rafales de vent",		//23
			"Venteux",				//24
			"Froid",				//25
			"Nuageux",				//26
			"Nuageux",				//27
			"Nuageux",				//28
			"Part. nuageux",		//29
			"Part. nuageux",		//30
			"Clair",				//31
			"Clair",				//32
			"Beau temps",			//33
			"Beau temps",			//34
			"Pluie + grêle",		//35
			"Chaud",				//36
			"Orages isolés",		//37
			"Averses éparses",		//38
			"Averses éparses",		//39
			"Averses éparses",		//40
			"Forte neige",			//41
			"Bourrasques",			//42
			"Forte neige",			//43
			"Part. nuageux",		//44
			"Orages",				//45
			"Part. nuageux",		//46
			"Part. nuageux",		//47
			"Non Disponibile"		//48 (3200)
		]
	},
	"en": {
		"strings": {
			"NOW_AT": "Now at ",
			"THIS_WEEK": "This week :",
			"DAY": "Day",
			"LOW": "Low",
			"HIGH": "Max",
			"TEMP": "Cond."
		},
		"weekdays": {
			"Sun": "Sun",
			"Mon": "Mon",
			"Tue": "Tue",
			"Wed": "Wed",
			"Thu": "Thu",
			"Fri": "Fri",
			"Sat": "Sat"
		}
		//How to get from http://developer.yahoo.com/weather/#codes :
		//var mystr = ""; var cols = codetable.getElementsByTagName("td"); for (var i = 1; i < cols.length; i += 2) { mystr += "\""+cols[i].innerText+"\"\n" }
		/*"weather": [
			"tornado",
			"tropical storm",
			"hurricane",
			"severe thunderstorms",
			"thunderstorms",
			"mixed rain and snow",
			"mixed rain and sleet",
			"mixed snow and sleet",
			"freezing drizzle",
			"drizzle",
			"freezing rain",
			"showers",
			"showers",
			"snow flurries",
			"light snow showers",
			"blowing snow",
			"snow",
			"hail",
			"sleet",
			"dust",
			"foggy",
			"haze",
			"smoky",
			"blustery",
			"windy",
			"cold",
			"cloudy",
			"mostly cloudy (night)",
			"mostly cloudy (day)",
			"partly cloudy (night)",
			"partly cloudy (day)",
			"clear (night)",
			"sunny",
			"fair (night)",
			"fair (day)",
			"mixed rain and hail",
			"hot",
			"isolated thunderstorms",
			"scattered thunderstorms",
			"scattered thunderstorms",
			"scattered showers",
			"heavy snow",
			"scattered snow showers",
			"heavy snow",
			"partly cloudy",
			"thundershowers",
			"snow showers",
			"isolated thundershowers",
			"not available"
		]*/
	}
}

function localize (string, key, fallback) {
	key = typeof key !== 'undefined' ? key : "strings";
	if (typeof localized[lang][key] === 'undefined') {
		return typeof fallback !== 'undefined' ? fallback : string;
	}
	return localized[lang][key][string];
}