var weather = new Array();
weather['locale'] = "CAXX0071";
weather['tmp_unit'] = "c";
var updateInterval = 10;
var lang = "fr";

/*[uConfig]*/
//DO NOT MANUALLY EDIT!!!
var lang = "fr";
weather['locale'] = "CAXX0071";
weather['tmp_unit'] = "c";
