document.body.onload = function(){
  var html = document.body.innerHTML;
  document.body.innerHTML = "<button style=\"width: 100%; height: 50px; \" onclick=\"alert('Hello, World!');\">Je suis un gros bouton :P</button>"+html;
}