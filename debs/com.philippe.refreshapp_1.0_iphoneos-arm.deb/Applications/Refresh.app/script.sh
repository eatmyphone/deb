#!/bin/sh

uicache
