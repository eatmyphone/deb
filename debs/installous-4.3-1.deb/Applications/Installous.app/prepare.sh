#!/bin/bash

killall Installous
#killall Installous_

#mv Installous Installous_
#mv Installous_Launch Installous

#chmod 4777 Installous_
chmod 0777 Installous
chown mobile:mobile Installous

chmod 4777 clutch_crack_binary
chown root:wheel clutch_crack_binary
